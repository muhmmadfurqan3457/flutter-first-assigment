package com.example.muhammadfurqan

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
